<?php
session_start();
include('includes/header.php'); 
include('../config/dbcon.php');
$cust_id = $_SESSION['auth_user']['user_id'];
?>

<div class="container-fluid px-4">
    <h1 class="mt-4">Lokasi</h1>
    <ol class="breadcrumb mb-4">
        <li class="breadcrumb-item active">Profil Saya</li>
        <li class="breadcrumb-item">Lokasi</li>
    </ol>
    <div class="row">

        <div class="col-md-12 mb-5">

            <?php include('message.php'); ?>

            <div class="card">
                <div class="card-header">
                    
                    <h4>Lokasi Anda 
                    <a href="destination-add.php" class="btn btn-primary float-end">Tambah Lokasi</a><a href="profile.php" class="btn btn-secondary float-end mx-3">Kembali</a>
                    </h4>
                </div>
                <div class="card-body">
                    <table class="table table-bordered">    
                        <thead>
                            <tr>
                                <th>Lokasi</th>
                                <th>Alamat</th>
                                <th>Ubah</th>
                                <th>Hapus</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $query = "SELECT * FROM destination where cust_id=$cust_id";
                            $query_run = mysqli_query($con, $query);

                            if(mysqli_num_rows($query_run) > 0)
                            {
                                foreach($query_run as $row)
                                {
                                    ?>
                                        <tr>
                                            <td><?= $row['location'] ?></td>
                                            <td><?= $row['address'] ?></td>
                                            <td><a href="destination-edit.php?destination_id=<?=$row['destination_id']?>" class="btn btn-success">Ubah</a></td>
                                            <td>
                                                <form action="crud.php" method="post">   
                                            <button type="submit" name="delete_destination" value="<?=$row['destination_id']?>" class="btn btn-danger">Hapus</button></td>
                                                </form> 
                                        </tr>
                                    <?php

                                }
                            }
                            else
                            {
                             ?>
                                    <tr>
                                        <td coldspan="4">Tidak Ada Lokasi yang Ditemukan</td>
                                    </tr>
                             <?php   
                            }
                            ?>

                        </tbody>
                    </table>

                </div>
            </div>
        </div>
    </div>
</div>    
                                
<?php 
include('includes/footer.php');
?>